Portfolio consultable à l'adresse suivante :
http://tracteurunix8664.ddns.net/valentin-charbonneau/


Le fichier index.html est la racine du portfolio.

Un seul fichier css : style.css, est utilisé par toutes les pages html.

Le script : script.js, est utilisé par toutes les pages, à l'exception de CV.html.
Chaque page a également un script javascript supplémentaire répondant aux spécificités de chacune.